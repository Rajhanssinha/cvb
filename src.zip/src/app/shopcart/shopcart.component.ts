import { Component, OnInit } from '@angular/core';
import { ForcartService } from '../forcart.service';
import { PizzaaService } from '../pizzaa.service';

@Component({
  selector: 'app-shopcart',
  templateUrl: './shopcart.component.html',
  styleUrls: ['./shopcart.component.css'],
  providers:[PizzaaService]
})
export class ShopcartComponent implements OnInit {

  public product :any = [];
  public finalcost !: number;
  public finalCost1 !: number;


  constructor(private forcartService : ForcartService, private pizzaaService:PizzaaService) { }

  ngOnInit(): void {
   this.forcartService.getPizza().subscribe(res=>{
     this.product=res;
     this.finalCost1=this.forcartService.getPrice();
     this.finalcost=0.05*this.finalCost1+this.finalCost1;
   }) 
  }
  removePizza(pizza:any){
    this.forcartService.removeCartPizza(pizza);
    this.finalcost=this.finalcost-pizza.price-0.05*pizza.price;
  }

  emptycart(){
    this.forcartService.removeAllPizza();
    this.finalcost=0;
  }
  registerUser(pizzas: any){
    console.log(pizzas);
    this.pizzaaService.registerUser(pizzas);
  }

}
