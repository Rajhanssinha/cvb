import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class IngredientssService {

  constructor(private http:HttpClient) { }
  getAllIngredient()
  {
    return this.http.get('http://localhost:3001/getingredients')
  }
}
