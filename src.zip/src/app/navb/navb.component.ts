import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navb',
  templateUrl: './navb.component.html',
  styleUrls: ['./navb.component.css']
})
export class NavbComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
