import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class PizzaaService {

  constructor(private http:HttpClient) { }
  getAllPizza(){
    return this.http.get('http://localhost:3001/getPizza')
  }


registerUser(pizzas: any){
  this.http.post('http://localhost:3001/addOrder',pizzas)
  .subscribe(res=>{
    console.log(res);
  })
}

  getReviews(){
    return this.http.get('http://localhost:3001/getOrder')
  }
}

