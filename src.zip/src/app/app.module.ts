import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbComponent } from './navb/navb.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BuildpizzaComponent } from './buildpizza/buildpizza.component';
import { OrderpComponent } from './orderp/orderp.component';
import { ShopcartComponent } from './shopcart/shopcart.component';
import { ThankyouComponent } from './thankyou/thankyou.component';
import { ReviewsComponent } from './reviews/reviews.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbComponent,
    BuildpizzaComponent,
    OrderpComponent,
    ShopcartComponent,
    ThankyouComponent,
    ReviewsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule, HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
