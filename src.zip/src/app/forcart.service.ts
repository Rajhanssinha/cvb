import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ForcartService {
  public pizzacart: any=[];
  public pizzaList= new BehaviorSubject<any>([]);

  constructor() { }
  getPizza(){
    return this.pizzaList.asObservable();
  }

  // setProducts(product : any){
  //   this.pizzacart.push(...product);
  //   this.pizzaList.next(product);
  // }

  addtoCart(product: any){
    this.pizzacart.push(product);
    this.pizzaList.next(this.pizzacart);
    this.getPrice();
    console.log(this.pizzacart)
  }

  getPrice() : number {
    let totalprice=0;
    this.pizzacart.map((a:any)=>{
      totalprice += a.total;
    })
    return totalprice;
  }
  
  removeCartPizza(product :any){
    this.pizzacart.map((a:any,index:any)=>{
      if(product.id===a.id){
        this.pizzacart.splice(index,1)
      }
    })
  }

  removeAllPizza(){
    this.pizzacart=[]
    this.pizzaList.next(this.pizzacart);
  }

}

