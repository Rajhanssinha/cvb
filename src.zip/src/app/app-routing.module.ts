import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BuildpizzaComponent } from './buildpizza/buildpizza.component';
import { ShopcartComponent } from './shopcart/shopcart.component';
import { NavbComponent } from './navb/navb.component';
import { OrderpComponent } from './orderp/orderp.component';
import { ThankyouComponent } from './thankyou/thankyou.component';
import { ReviewsComponent } from './reviews/reviews.component';

const routes: Routes = [
  {path: 'buildpizza', component: BuildpizzaComponent},
  {path: 'orderp' , component: OrderpComponent},
  {path :'navb' , component:NavbComponent},
  {path:'shopcart' , component:ShopcartComponent},
  {path:'thankyou' , component:ThankyouComponent},
  {path:'review' , component:ReviewsComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
