import { TestBed } from '@angular/core/testing';

import { ForcartService } from './forcart.service';

describe('ForcartService', () => {
  let service: ForcartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ForcartService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
