import { TestBed } from '@angular/core/testing';

import { PizzaaService } from './pizzaa.service';

describe('PizzaaService', () => {
  let service: PizzaaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PizzaaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
