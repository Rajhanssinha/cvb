import { TestBed } from '@angular/core/testing';

import { IngredientssService } from './ingredientss.service';

describe('IngredientssService', () => {
  let service: IngredientssService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IngredientssService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
